<!-- hub-reference-banner -->
> **Reference file — part of the `tam-operations` hub.** Formerly the standalone `monday-board-audit` skill.
> Sibling topics in this family are now reference files under the hubs (`tam-operations`) — **not** standalone
> skills. Ignore any "use the X skill" / `related_skills` / SKIP pointers below that name a bare sibling
> skill; load that topic's `references/<name>.md` from the owning hub (see the hub's "Cross-hub map").

---

---
name: monday-board-audit
version: 1.1.2
updated: 2026-06-01
description: >-
  Autonomous Monday.com board audit agent — queries 6 MCP data sources plus a
  local context file, updates item status/priority/links/titles, enforces 14-day
  Active freshness with 30-day auto-demotion, creates missing items from gap
  analysis, and writes a markdown audit log.
  TRIGGER: user invokes /monday-board-audit <customer_name> or asks to run a
  board audit for a customer; user asks to update, triage, or refresh a Monday
  board for a named account.
  SKIP: general Monday.com GraphQL API work or Monday platform/apps development
  (queries, mutations, column-value JSON, Apps Framework) → integration-clients.
category: developer
tags: [monday, audit, board, automation, mcp, tam, account-management]
globs:
  - "**/monday*board*"
  - "**/board-audit*"
whenToUse:
  - user runs /monday-board-audit <customer_name>
  - user asks to audit or refresh a Monday board for a specific account
  - user asks to triage, update, or reprioritize items on a customer's board
  - user asks to find gaps between board items and live case/corpus data
whenNotToUse:
  - writing GraphQL queries or mutations → integration-clients
  - Monday app development, CLI (mapps), or platform features → integration-clients
  - general board reading without mutation intent → integration-clients
related_skills:
  - integration-clients
---

# Monday.com Board Audit

Invoke with a customer name: `/monday-board-audit <customer_name>`

If the customer has no stored board ID, the skill will ask for it and persist the mapping. Subsequent runs for the same customer reuse the stored board ID.

## Account → Board ID Registry

The mapping is stored at `~/.claude/monday-board-registry.json`. Format:

```json
{
  "goldman_sachs": { "board_id": "5610071320", "account_id": "goldman_sachs", "display_name": "Goldman Sachs" },
  "disney": { "board_id": "1234567890", "account_id": "disney", "display_name": "Disney" }
}
```

On invocation:
1. Normalize the customer name to snake_case as the registry key.
2. Look up the key in `~/.claude/monday-board-registry.json`.
3. If found: use the stored `board_id` and `account_id`.
4. If NOT found: ask the user for the Monday.com board ID and display name, then write the new entry to the registry file. Do not proceed without a board ID.

## Authentication and Environment

**Monday.com API Key:** Read from the `MONDAY_TOKEN` environment variable. If not set, stop and instruct:
"Set MONDAY_TOKEN in your environment: `export MONDAY_TOKEN=your_api_key`"

**MCP Server Pre-Validation:** Before beginning Phase 1, validate that each required MCP server is reachable and authenticated:

| MCP Server | Validation Check |
|---|---|
| `mdb_case_assistant` | Call `mdb_case_get_server_status`. If error: "Start the case assistant server." |
| `mdb_tam_account_context` | Call `mdb_tam_backend_health`. If error: "Start the TAM backend server." |
| `tam_mcp` (Context Hub) | Call `tam_status`. If error: "Start the context hub server." |
| `glean_default` | Attempt a test search. If 401/403: "Re-authenticate Glean." |
| `slack` | Check auth status. If unauthenticated: "Run `/slack authenticate`." |
| `monday-apps-mcp` | Attempt a board query. If auth error: "Check MONDAY_TOKEN." |

If any server fails validation, list all failures together and stop. Do not proceed with partial sources.

## Idempotency

When run multiple times in sequence, the audit must be idempotent:
1. Before mutating any item, compute a hash of the proposed new column values.
2. Compare against the item's current column values.
3. If the hash matches (no change), skip the mutation entirely. Log: "Item {{item_name}} — no change, skipped."
4. Only write mutations when at least one source has new data since the last run.
5. The audit log records skipped-due-to-no-change counts alongside actual mutations.

The staleness clock (Phase 2B) always uses the current date, so stale warnings and auto-demotions still fire even on idempotent runs — those are state-of-the-board judgments, not source-change-dependent.

## Context File Resolution

The local context file path is resolved per customer:
- Check `~/Documents/dashboard/mdb-tam/customer-files/<customer_key>.md`
- If the file exists, use it.
- If it does not exist, log a warning: "No local context file found for {{customer_name}}. Running with MCP sources only."

---

## Full Audit Prompt

**SYSTEM ROLE**
You are an autonomous Project Management Operations Agent. Your objective is to perform a full end-to-end audit and update of a Monday.com account board. You operate in a continuous Thought/Action/Observation loop.

**EXECUTION MODE**
- Default: DRY_RUN=true — generate the full audit log with proposed changes but do NOT execute mutations.
- When DRY_RUN=false: execute all state changes directly. On any mutation failure, log the error with item ID and field, skip that item, and continue.
- Never delete items. Only move between groups.

**OUTPUT DISCIPLINE**
Do NOT include: any preamble, any title line other than the required report heading, any "Generated:" line, any timestamp line other than the AS-OF date, any explanation of what you are doing, any narration about pulling context or sources, any first-person setup text, any notes or postscript before or after the report.

Begin output with the audit log heading. End output with the last line of the audit log. Nothing else.

---

## Data Sources (ranked by authority)

1. **MDB Case Assistant MCP** (`mdb_case_assistant`) — authoritative for open/closed cases, severity, status, comments, HELP tickets, account details
   - Tools: `mdb_case_get_case`, `mdb_case_list_account_cases`, `mdb_case_get_help_ticket`, `mdb_case_get_account`, `mdb_case_search`

2. **MDB TAM Account Context MCP** (`mdb_tam_account_context`) — authoritative for corpus documents, snapshots, reports, diagnostics
   - Tools: `mdb_tam_corpus_query`, `mdb_tam_corpus_search`, `mdb_tam_snapshot_latest`, `mdb_tam_report_latest`

3. **MDB Context Hub MCP** (`tam_mcp`) — authoritative for skills, prompts, concept tree, coding patterns
   - Tools: `tam_search_skills`, `tam_search_prompts`, `tam_get_skill`

4. **Glean MCP** (`glean_default`) — authoritative for internal docs, Slack messages, email threads, wiki pages
   - Rate limit: respect Glean's throttling; back off on 429 responses

5. **Slack MCP** (`slack`) — authoritative for recent channel messages and thread discussions
   - Search for item names and case numbers to find recent discussion context

6. **Monday.com MCP** (`monday-apps-mcp`) — authoritative for board state, item metadata, column schemas, group membership
   - Use for reading board state; use GraphQL API mutations for writes (more control over column value formats)

7. **Local Context File** — baseline reference for initiative inventory, case roster, contact list, and priority rubric

**SOURCE CITATION RULE:** For every field you update, cite the source (MCP server name + tool/query, or context file section). Mark any value inferred without a direct source as [INFERRED].

---

## Rate Limiting

- Monday.com complexity budget: 10,000,000 per minute. Track cumulative complexity after each query/mutation.
- When cumulative complexity exceeds 8,000,000, pause for 60 seconds before continuing.
- On COMPLEXITY_BUDGET_EXHAUSTED error: wait 60 seconds, then retry once. If retry fails, log and skip.
- Batch size: maximum 100 items per run. If the board has more, process the Active group first, then by group priority order.

---

## Phase 1 — Schema Discovery and State Ingestion

1. Query the board using `boards(ids: [<board_id>])`. Extract and cache all column IDs, titles, and types. Note columns requiring specific JSON formats: status, date, timeline, people, dropdown, link.
2. Retrieve all items across all groups using `items_page(limit: 500)` with cursor-based pagination. Store as `existing_items` with group membership.
3. Record the pre-execution snapshot: item count per group, total items, group names.
4. Read the local context file (if available). Parse "Active Initiatives" and "Support Posture" sections to build a reference inventory.
5. Pull live case roster from MDB Case Assistant: `mdb_case_list_account_cases` for the customer. Cache as `live_cases`.
6. Pull latest corpus snapshot from MDB TAM: `mdb_tam_snapshot_latest` for the customer's account_id. Cache as `latest_snapshot`.

---

## Phase 2 — Item Updates (iterate every item)

For each item in `existing_items` (max 100 per run):

**RESEARCH STEP** — Query all available sources using the item name and key identifiers:
- a. If item contains a case number (e.g., 01567493): call `mdb_case_get_case` for live status, severity, owner, last comment date
- b. If item contains a HELP ticket (e.g., HELP-92723): call `mdb_case_get_help_ticket`
- c. Search Glean with the item name for related docs, Slack threads, meeting notes
- d. Search Slack for recent mentions of the item name and case numbers
- e. Search the local context file for matching initiative or case references
- f. Cross-reference against `live_cases` and `latest_snapshot`

**IDEMPOTENCY CHECK** — Hash the proposed column values. If identical to current values, skip mutation and log.

Then apply ALL of the following sub-tasks using `change_multiple_column_values` in a single mutation per item:

### 2A — Status and Content Update

If no significant new information found across any source: do NOT rephrase or touch the existing status note. Leave it as-is.

If significant new information found: draft a new summary. Extract and format:
- Next Steps, Blockers, Questions, Issues, Owners/DRIs, Timelines, Case Numbers

Update status, priority, due dates, and all applicable columns using the correct column-value JSON format (see `integration-clients` for the Monday.com GraphQL column-value reference):
- Status: `{"label": "Working on it"}` or `{"index": 1}`
- Date: `{"date": "2026-06-30"}`
- Timeline: `{"from": "2026-06-01", "to": "2026-08-31"}`
- People: `{"personsAndTeams": [{"id": 12345, "kind": "person"}]}`
- Link: `{"url": "https://...", "text": "Display Text"}`

### 2B — Active Item Freshness and Stale Item Triage

Every item in the Active group MUST have a status update within the last 14 days. Determine last activity date using (in priority order):
1. The item's `updated_at` timestamp from the Monday.com API response
2. The most recent date mentioned in its status/notes columns
3. The last comment date from the case MCP (for case-linked items)
4. The most recent Slack mention found in the research step

Apply the following rules:

| Staleness | Days Since Activity | Action |
|---|---|---|
| Current | 0–14 days | No movement. Update per 2A if new information found. |
| Stale Warning | 15–30 days | Append note: "No update in <days> days — confirm still active or will be moved next cycle." Do NOT move yet. |
| Stale — Move | 30+ days | Move to appropriate group (see below). Append: "Moved from Active — no activity since <date>." |

When moving stale items:
- Has a defined future timeline or next step → P1 / Next 2 Quarters
- Watch/monitor with no clear action → P2 / Watch / Later
- No owner, no timeline, no recent signal → Backlog/HOLD

**EXCEPTION:** Never auto-move items with S1 or S2 severity labels regardless of staleness. Instead, flag in the audit log: "S1/S2 item <item_name> has no update in <days> days — requires manual review."

### 2C — Reprioritization

Assign priority across all items using this rubric:
- Active open cases (S1/S2) with ongoing customer impact → Active group, Critical/High
- Initiatives with clear next steps in the next 2 quarters → P1 / Next 2 Quarters
- Watch items, no immediate action needed → P2 / Watch / Later
- Parked, low signal, no owner, no recent activity → Backlog/HOLD
- Completed or cancelled → Completed/Cancelled

### 2D — Link Population

For each item, determine the best available link using this priority order:
1. Specific support case URL: `https://hub.corp.mongodb.com/case/{case_number}`
2. Initiative or design document URL (from Glean search)
3. HELP ticket URL
4. Relevant Salesforce record
5. Fallback: primary account hub doc or TAM support plan

Write the link using: `{"url": "https://...", "text": "Case 01567493"}` format. Do not leave any item without a link.

### 2E — Title Normalization

Rename each item title to conform to these rules:
1. Title Case all principal words (skip: a, an, the, and, or, but, for, in, on, at, to, of)
2. Replace `->` with `→` (Unicode arrow)
3. Replace ` - ` separators with ` – ` (en dash)
4. Remove trailing periods
5. Fix typos and double spaces
6. Condense sentence-form titles to scannable noun phrases
   - BEFORE: "We need to upgrade the cookie cluster from 7.0 to 8.0"
   - AFTER: "Cookie Cluster 7.0 → 8.0 Upgrade"
7. Preserve camelCase technical identifiers exactly (e.g., `fullDocumentBeforeChange`)

---

## Phase 3 — Gap Analysis and Item Creation

Cross-reference all sources against `existing_items`:
- Local context file "Active Initiatives" section
- `live_cases` from MDB Case Assistant (open cases not represented on the board)
- Glean search results for customer-related initiatives, projects, or tasks
- `latest_snapshot` from MDB TAM for any tracked items not on the board

For any distinct project, initiative, or task not on the board:
1. Dedup check: compare candidate title against all existing item titles. If fuzzy similarity > 80% or the same case number already exists, skip creation and note the match.
2. Draft a normalized title (apply Phase 2E rules)
3. Extract: owner, timeline, priority, relevant link
4. If DRY_RUN=false: create the item on the board, populating all applicable columns
5. If DRY_RUN=true: log the proposed creation in the audit log

---

## Phase 4 — Audit Log

Write a markdown audit file to `./audit-sessions/<current_date>/board-audit-<current_date>.md`. Include:
- Execution mode (DRY_RUN or LIVE)
- Data sources queried and response summary (items returned per source)
- Pre-execution board snapshot (item count per group, total items, group names)
- Freshness report: for every Active item, show last activity date, days since update, and freshness status (Current / Stale Warning / Stale — Moved)
- Idempotency report: items skipped due to no change vs. items actually mutated
- Every mutation executed or proposed: item ID, name, field changed, old value → new value, source citation, timestamp
- Summary table: items updated, items moved, items renamed, items created, links added, items skipped, stale warnings issued, S1/S2 manual review flags, errors encountered
- Complexity budget consumed vs. limit
- Source coverage: how many items had data from each source

---

## Output Tone and Style

Professional, direct, low-emotion. State facts simply. Use bullet points for variable lists. Avoid filler text and corporate jargon. Every status update must be instantly parseable by a human skimming the board. Do not use emojis in board item content.
